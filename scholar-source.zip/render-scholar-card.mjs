import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { SCHOLAR_ID, SOURCE_URL } from './update-scholar.mjs';

const ROOT = dirname(fileURLToPath(import.meta.url));

export function renderScholarSvg(document) {
  const fields = ['schema_version', 'scholar_id', 'citations', 'h_index', 'i10_index', 'updated_at', 'source_url'];
  if (!document || typeof document !== 'object' || Array.isArray(document)
    || Object.keys(document).length !== fields.length
    || fields.some(key => !Object.hasOwn(document, key))
    || document.schema_version !== 1 || document.scholar_id !== SCHOLAR_ID
    || document.source_url !== SOURCE_URL) {
    throw new Error('Expected the complete verified Scholar JSON schema; fixture input is not publishable.');
  }
  for (const key of ['citations', 'h_index', 'i10_index']) {
    if (!Number.isSafeInteger(document[key]) || document[key] < 0) throw new Error(`Invalid ${key}.`);
  }
  if (typeof document.updated_at !== 'string'
    || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(document.updated_at)) {
    throw new Error('updated_at must be the successful retrieval time in UTC ISO format.');
  }
  const updated = new Date(document.updated_at);
  if (!Number.isFinite(updated.getTime()) || updated.toISOString() !== document.updated_at
    || updated.getTime() > Date.now() + 300000) {
    throw new Error('Invalid or future successful retrieval time.');
  }
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(updated).map(({ type, value }) => [type, value]));
  const date = `${parts.year}-${parts.month}-${parts.day}`;
  const number = new Intl.NumberFormat('en-US');
  const metrics = [
    ['引用次数', document.citations, 2],
    ['h-index', document.h_index, 142],
    ['i10-index', document.i10_index, 270],
  ];
  // All inserted text is fixed labels, validated integers, or a formatted date.
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="400" height="90" viewBox="0 0 400 90" role="img" aria-labelledby="title description">
  <title id="title">Google Scholar 累计指标</title>
  <desc id="description">引用次数 ${document.citations}，h-index ${document.h_index}，i10-index ${document.i10_index}。成功更新于 ${date}（北京时间）。</desc>
  <rect width="400" height="90" fill="#f3f7fa"/>
  <g font-family="Arial, Microsoft YaHei, PingFang SC, sans-serif">
${metrics.map(([label, value, x]) => `    <text x="${x}" y="18" fill="#536878" font-size="12">${label}</text>
    <text x="${x}" y="47" fill="#244f6b" font-size="24" font-weight="700">${number.format(value)}</text>`).join('\n')}
    <text x="2" y="75" fill="#607484" font-size="11">更新于 ${date}（北京时间）· 以学术主页为准</text>
  </g>
</svg>
`;
}

export async function renderFile({
  inputPath = join(ROOT, 'docs', 'scholar-metrics.json'),
  outputPath = join(ROOT, 'docs', 'scholar-metrics.svg'),
} = {}) {
  const svg = renderScholarSvg(JSON.parse(await readFile(inputPath, 'utf8')));
  await mkdir(dirname(outputPath), { recursive: true });
  const temporaryPath = `${outputPath}.${process.pid}.${Date.now()}.tmp`;
  try {
    await writeFile(temporaryPath, svg, { encoding: 'utf8', flag: 'wx' });
    await rename(temporaryPath, outputPath);
  } catch (error) {
    await unlink(temporaryPath).catch(() => {});
    throw error;
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  renderFile().then(() => console.log('Rendered docs/scholar-metrics.svg from the verified JSON.')).catch(error => {
    console.error(`Render failed: ${error.message}`);
    process.exitCode = 1;
  });
}
