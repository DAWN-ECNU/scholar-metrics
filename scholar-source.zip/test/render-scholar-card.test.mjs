import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { renderFile, renderScholarSvg } from '../render-scholar-card.mjs';
import { SCHOLAR_ID, SOURCE_URL } from '../update-scholar.mjs';

// Complete synthetic documents remain inside tests; none is written into docs/.
const valid = () => ({ schema_version: 1, scholar_id: SCHOLAR_ID, citations: 1234, h_index: 17,
  i10_index: 23, updated_at: '2026-01-20T23:30:00.000Z', source_url: SOURCE_URL });
const HERE = dirname(fileURLToPath(import.meta.url));

test('renders self-contained metrics and converts the successful date to Beijing time', () => {
  const svg = renderScholarSvg(valid());
  assert.match(svg, /viewBox="0 0 400 90"/);
  assert.match(svg, />1,234<\/text>/);
  assert.match(svg, />17<\/text>/);
  assert.match(svg, />23<\/text>/);
  assert.match(svg, /更新于 2026-01-21（北京时间）/);
  assert.doesNotMatch(svg, /<script|<image|href=|@import/i);
});

test('rejects fixture-only, incomplete, wrong-author, invalid-date and invalid-value data', () => {
  const incomplete = valid();
  delete incomplete.source_url;
  for (const document of [
    { fixture_only: true, scholar_id: SCHOLAR_ID, citations: 1234, h_index: 17, i10_index: 23 },
    { ...valid(), fixture_only: true }, incomplete,
    { ...valid(), scholar_id: 'wrong' }, { ...valid(), source_url: 'https://example.com' },
    { ...valid(), updated_at: '2026-02-30T00:00:00.000Z' },
    { ...valid(), updated_at: '2999-01-01T00:00:00.000Z' },
    { ...valid(), citations: -1 }, { ...valid(), h_index: '17' },
  ]) assert.throws(() => renderScholarSvg(document));
});

test('invalid input leaves the previous SVG unchanged; valid input replaces it', async () => {
  const temporary = await mkdtemp(join(HERE, '.tmp-'));
  try {
    const inputPath = join(temporary, 'input.json');
    const outputPath = join(temporary, 'output.svg');
    const old = '<svg xmlns="http://www.w3.org/2000/svg"><!-- prior test image --></svg>\n';
    await writeFile(outputPath, old);
    await writeFile(inputPath, JSON.stringify({ fixture_only: true }));
    await assert.rejects(renderFile({ inputPath, outputPath }));
    assert.equal(await readFile(outputPath, 'utf8'), old);
    await writeFile(inputPath, JSON.stringify(valid()));
    await renderFile({ inputPath, outputPath });
    assert.equal(await readFile(outputPath, 'utf8'), renderScholarSvg(valid()));
  } finally {
    assert.equal(dirname(temporary), HERE);
    await rm(temporary, { recursive: true, force: true });
  }
});
