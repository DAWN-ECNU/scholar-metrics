import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { parseSerpApiMetrics, runUpdate, SCHOLAR_ID, SOURCE_URL } from '../update-scholar.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const KEY = 'synthetic-serpapi-key-not-a-real-credential';
const fixture = async () => JSON.parse(await readFile(join(HERE, 'fixtures', 'serpapi-author.json'), 'utf8'));

function mockApi(data, { status = 200, networkError, jsonError } = {}) {
  let count = 0;
  return {
    calls: () => count,
    fetchImpl: async (request, options) => {
      count += 1;
      const url = new URL(request);
      assert.equal(url.origin, 'https://serpapi.com');
      assert.equal(url.pathname, '/search.json');
      assert.equal(url.searchParams.get('engine'), 'google_scholar_author');
      assert.equal(url.searchParams.get('author_id'), SCHOLAR_ID);
      assert.equal(url.searchParams.get('hl'), 'en');
      assert.equal(url.searchParams.get('api_key'), KEY);
      assert.equal(options.redirect, 'error');
      if (networkError) throw new Error(networkError);
      return { ok: status === 200, status, json: async () => {
        if (jsonError) throw new Error(jsonError);
        return data;
      } };
    },
  };
}

test('SerpApi reads all-time metrics by their English field names', async () => {
  assert.deepEqual(parseSerpApiMetrics(await fixture()), { citations: 1234, h_index: 17, i10_index: 23 });
});

test('a configured key uses only SerpApi and preserves the original seven-field output schema', async () => {
  const temporary = await mkdtemp(join(HERE, '.tmp-'));
  try {
    const outputPath = join(temporary, 'metrics.json');
    const mock = mockApi(await fixture());
    await runUpdate({ fetchImpl: mock.fetchImpl, outputPath, apiKey: KEY });
    const data = JSON.parse(await readFile(outputPath, 'utf8'));
    assert.deepEqual(Object.keys(data), ['schema_version', 'scholar_id', 'citations', 'h_index', 'i10_index', 'updated_at', 'source_url']);
    assert.equal(data.scholar_id, SCHOLAR_ID);
    assert.equal(data.source_url, SOURCE_URL);
    assert.equal(data.citations, 1234);
    assert.equal(mock.calls(), 1);
    assert.ok(!JSON.stringify(data).includes(KEY));
  } finally {
    assert.equal(dirname(temporary), HERE);
    await rm(temporary, { recursive: true, force: true });
  }
});

test('wrong author, missing fields, and API errors preserve the old JSON without exposing raw messages', async () => {
  const cases = [];
  const wrongAuthor = await fixture();
  wrongAuthor.search_parameters.author_id = 'another-author';
  cases.push(wrongAuthor);
  const missing = await fixture();
  delete missing.cited_by.table[1].h_index.all;
  cases.push(missing);
  cases.push({ error: `RAW_PRIVATE_RESPONSE ${KEY}`, search_metadata: { status: 'Error' } });
  for (const data of cases) {
    const temporary = await mkdtemp(join(HERE, '.tmp-'));
    try {
      const outputPath = join(temporary, 'metrics.json');
      const old = '{"synthetic_previous_test_value":true}\n';
      await writeFile(outputPath, old);
      const mock = mockApi(data);
      await assert.rejects(runUpdate({ fetchImpl: mock.fetchImpl, outputPath, apiKey: KEY }), error => {
        assert.ok(!error.message.includes(KEY));
        assert.ok(!error.message.includes('RAW_PRIVATE_RESPONSE'));
        return true;
      });
      assert.equal(await readFile(outputPath, 'utf8'), old);
      assert.equal(mock.calls(), 1);
    } finally {
      assert.equal(dirname(temporary), HERE);
      await rm(temporary, { recursive: true, force: true });
    }
  }
});

test('HTTP, network, and JSON failures preserve the old file and sanitize private error details', async () => {
  for (const options of [ { status: 401 }, { networkError: `RAW_PRIVATE_RESPONSE ${KEY}` }, { jsonError: `RAW_PRIVATE_RESPONSE ${KEY}` } ]) {
    const temporary = await mkdtemp(join(HERE, '.tmp-'));
    try {
      const outputPath = join(temporary, 'metrics.json');
      const old = '{"synthetic_previous_test_value":true}\n';
      await writeFile(outputPath, old);
      const mock = mockApi(await fixture(), options);
      await assert.rejects(runUpdate({ fetchImpl: mock.fetchImpl, outputPath, apiKey: KEY }), error => {
        assert.ok(!error.message.includes(KEY));
        assert.ok(!error.message.includes('RAW_PRIVATE_RESPONSE'));
        return true;
      });
      assert.equal(await readFile(outputPath, 'utf8'), old);
      assert.equal(mock.calls(), 1);
    } finally {
      assert.equal(dirname(temporary), HERE);
      await rm(temporary, { recursive: true, force: true });
    }
  }
});

test('the real CLI error log never prints a key, request URL, or underlying private error', () => {
  const mockCode = "globalThis.fetch = async () => { throw new Error('RAW_PRIVATE_RESPONSE https://serpapi.com/search.json?api_key=' + process.env.SERPAPI_API_KEY); };";
  const cli = spawnSync(process.execPath, ['--import', `data:text/javascript,${encodeURIComponent(mockCode)}`, join(dirname(HERE), 'update-scholar.mjs')], {
    encoding: 'utf8', env: { ...process.env, SERPAPI_API_KEY: KEY },
  });
  assert.equal(cli.status, 1);
  const logs = cli.stdout + cli.stderr;
  assert.match(logs, /SerpApi request failed/);
  assert.ok(!logs.includes(KEY));
  assert.ok(!logs.includes('https://serpapi.com'));
  assert.ok(!logs.includes('RAW_PRIVATE_RESPONSE'));
});
