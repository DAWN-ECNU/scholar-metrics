import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { parseScholarMetrics, runUpdate, SCHOLAR_ID, SOURCE_URL } from '../update-scholar.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = dirname(HERE);
const fixture = name => readFile(join(HERE, 'fixtures', `${name}.html`), 'utf8');

function mockFetch(html, status = 200, responseUrl = SOURCE_URL) {
  let calls = 0;
  const fetchImpl = async url => {
    calls += 1;
    assert.equal(url, SOURCE_URL);
    return { ok: status >= 200 && status < 300, status, url: responseUrl, text: async () => html };
  };
  return { fetchImpl, calls: () => calls };
}

test('reads the cumulative All column, not the recent column', async () => {
  const html = `${await fixture('valid')}<a href="/citations?user=anotherProfile">Synthetic coauthor</a>`;
  assert.deepEqual(parseScholarMetrics(html), { citations: 1234, h_index: 17, i10_index: 23 });
});

test('a successful mocked retrieval writes the required schema and a UTC timestamp', async () => {
  const temporary = await mkdtemp(join(HERE, '.tmp-'));
  try {
    const outputPath = join(temporary, 'scholar-metrics.json');
    const mock = mockFetch(await fixture('valid'));
    await runUpdate({ fetchImpl: mock.fetchImpl, outputPath, apiKey: '' });
    const actual = JSON.parse(await readFile(outputPath, 'utf8'));
    assert.equal(actual.schema_version, 1);
    assert.equal(actual.scholar_id, SCHOLAR_ID);
    assert.equal(actual.citations, 1234);
    assert.equal(actual.h_index, 17);
    assert.equal(actual.i10_index, 23);
    assert.equal(actual.source_url, SOURCE_URL);
    assert.match(actual.updated_at, /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    assert.equal(mock.calls(), 1);
  } finally {
    assert.equal(dirname(temporary), HERE);
    await rm(temporary, { recursive: true, force: true });
  }
});

for (const name of ['missing', 'captcha']) {
  test(`${name} input fails and leaves an existing JSON byte-for-byte unchanged`, async () => {
    const temporary = await mkdtemp(join(HERE, '.tmp-'));
    try {
      const outputPath = join(temporary, 'scholar-metrics.json');
      const old = '{"synthetic_previous_test_value":true}\n';
      await writeFile(outputPath, old);
      const mock = mockFetch(await fixture(name));
      await assert.rejects(runUpdate({ fetchImpl: mock.fetchImpl, outputPath, apiKey: '' }));
      assert.equal(await readFile(outputPath, 'utf8'), old);
      assert.equal(mock.calls(), 1);
      const cli = spawnSync(process.execPath, [join(ROOT, 'update-scholar.mjs'), '--fixture', join(HERE, 'fixtures', `${name}.html`)], { encoding: 'utf8' });
      assert.equal(cli.status, 1);
    } finally {
      assert.equal(dirname(temporary), HERE);
      await rm(temporary, { recursive: true, force: true });
    }
  });
}

test('rejects the wrong identity, labels, header, and a missing metric value', async () => {
  const html = await fixture('valid');
  assert.throws(() => parseScholarMetrics(html.replaceAll(SCHOLAR_ID, 'differentProfile')));
  assert.throws(() => parseScholarMetrics(html.replace('i10-index', 'other-index')));
  assert.throws(() => parseScholarMetrics(html.replace('<th>All</th>', '<th>Recent</th>')));
  assert.throws(() => parseScholarMetrics(html.replace('<td>23</td>', '<td></td>')));
});

test('HTTP errors fail without retrying and leave the existing JSON unchanged', async () => {
  const temporary = await mkdtemp(join(HERE, '.tmp-'));
  try {
    const outputPath = join(temporary, 'scholar-metrics.json');
    const old = '{"synthetic_previous_test_value":true}\n';
    await writeFile(outputPath, old);
    const mock = mockFetch('blocked', 429);
    await assert.rejects(runUpdate({ fetchImpl: mock.fetchImpl, outputPath, apiKey: '' }), /HTTP 429/);
    assert.equal(await readFile(outputPath, 'utf8'), old);
    assert.equal(mock.calls(), 1);
  } finally {
    assert.equal(dirname(temporary), HERE);
    await rm(temporary, { recursive: true, force: true });
  }
});

test('rejects a redirect to another profile and keeps the existing JSON unchanged', async () => {
  const temporary = await mkdtemp(join(HERE, '.tmp-'));
  try {
    const outputPath = join(temporary, 'scholar-metrics.json');
    const old = '{"synthetic_previous_test_value":true}\n';
    await writeFile(outputPath, old);
    const mock = mockFetch(await fixture('valid'), 200, 'https://scholar.google.com/citations?user=wrongProfile');
    await assert.rejects(runUpdate({ fetchImpl: mock.fetchImpl, outputPath, apiKey: '' }), /redirected/);
    assert.equal(await readFile(outputPath, 'utf8'), old);
    assert.equal(mock.calls(), 1);
  } finally {
    assert.equal(dirname(temporary), HERE);
    await rm(temporary, { recursive: true, force: true });
  }
});

test('fixture CLI is visibly test-only and never changes the published JSON', () => {
  const output = join(ROOT, 'docs', 'scholar-metrics.json');
  const existedBefore = existsSync(output);
  const before = existedBefore ? readFileSync(output) : null;
  const cli = spawnSync(process.execPath, [join(ROOT, 'update-scholar.mjs'), '--fixture', join(HERE, 'fixtures', 'valid.html')], { encoding: 'utf8' });
  assert.equal(cli.status, 0, cli.stderr);
  assert.equal(JSON.parse(cli.stdout).fixture_only, true);
  assert.equal(existsSync(output), existedBefore);
  if (existedBefore) assert.deepEqual(readFileSync(output), before);
});
