import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const SCHOLAR_ID = 'vR-ZpaEAAAAJ';
export const SOURCE_URL = `https://scholar.google.com/citations?user=${SCHOLAR_ID}&hl=en`;
const ROOT = dirname(fileURLToPath(import.meta.url));
const OUTPUT_PATH = join(ROOT, 'docs', 'scholar-metrics.json');

function decodeEntities(value) {
  const named = { amp: '&', quot: '"', apos: "'", nbsp: ' ', lt: '<', gt: '>' };
  return value.replace(/&(#x[0-9a-f]+|#\d+|amp|quot|apos|nbsp|lt|gt);/gi, (match, entity) => {
    if (!entity.startsWith('#')) return named[entity.toLowerCase()] ?? match;
    const code = entity[1].toLowerCase() === 'x'
      ? Number.parseInt(entity.slice(2), 16) : Number.parseInt(entity.slice(1), 10);
    return code <= 0x10ffff ? String.fromCodePoint(code) : match;
  });
}

function textContent(html) {
  return decodeEntities(html.replace(/<[^>]*>/g, '')).replace(/\s+/g, ' ').trim();
}

function attribute(tag, name) {
  const match = tag.match(new RegExp(`\\b${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i'));
  return match ? decodeEntities(match[1] ?? match[2] ?? match[3]) : null;
}

export function parseScholarMetrics(html) {
  if (/captcha-form|g-recaptcha|unusual traffic|not a robot|recaptcha\/api/i.test(html)) {
    throw new Error('Scholar returned a verification page; no update was saved.');
  }
  const tables = [...html.matchAll(/<table\b[^>]*>[\s\S]*?<\/table\s*>/gi)];
  const table = tables.find(([markup]) => attribute(markup.slice(0, markup.indexOf('>') + 1), 'id') === 'gsc_rsb_st')?.[0];
  if (!table) throw new Error('The Scholar metrics table gsc_rsb_st was not found.');

  // Publication-detail links identify this profile; coauthor-profile links do not.
  // Metric-label links can be JavaScript help popovers, so they are not identity evidence.
  const publicationLinks = [...html.matchAll(/<a\b[^>]*>/gi)].map(([tag]) => {
    const href = attribute(tag, 'href');
    if (!href) return null;
    const url = new URL(href, SOURCE_URL);
    return url.hostname === 'scholar.google.com' && url.pathname === '/citations'
      && url.searchParams.get('view_op') === 'view_citation' ? url : null;
  }).filter(Boolean);
  if (publicationLinks.length === 0 || publicationLinks.some(url =>
    url.searchParams.get('user') !== SCHOLAR_ID
    || !url.searchParams.get('citation_for_view')?.startsWith(`${SCHOLAR_ID}:`))) {
    throw new Error('The publication links do not identify the expected Scholar profile.');
  }

  const header = table.match(/<thead\b[^>]*>([\s\S]*?)<\/thead\s*>/i)?.[1];
  const headings = [...(header ?? '').matchAll(/<th\b[^>]*>([\s\S]*?)<\/th\s*>/gi)].map(match => textContent(match[1]));
  if (headings.length !== 3 || headings[1] !== 'All') {
    throw new Error('The cumulative All column could not be identified.');
  }
  const body = table.match(/<tbody\b[^>]*>([\s\S]*?)<\/tbody\s*>/i)?.[1];
  const rows = [...(body ?? '').matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr\s*>/gi)];
  const labels = ['Citations', 'h-index', 'i10-index'];
  if (rows.length !== labels.length) throw new Error('The metrics table must contain exactly three rows.');
  const values = rows.map((row, index) => {
    const cells = [...row[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td\s*>/gi)].map(match => textContent(match[1]));
    if (cells.length !== 3 || cells[0] !== labels[index]) {
      throw new Error(`Unexpected or missing metrics row: ${labels[index]}.`);
    }
    const raw = cells[1];
    if (!/^(?:0|[1-9]\d*|[1-9]\d{0,2}(?:,\d{3})+)$/.test(raw)) {
      throw new Error(`Invalid cumulative value for ${labels[index]}.`);
    }
    const value = Number(raw.replaceAll(',', ''));
    if (!Number.isSafeInteger(value) || value < 0) throw new Error('A metric is outside the supported integer range.');
    return value;
  });
  return { citations: values[0], h_index: values[1], i10_index: values[2] };
}

export async function runUpdate({ fetchImpl = globalThis.fetch, outputPath = OUTPUT_PATH } = {}) {
  // One public-page request per run; no CAPTCHA handling, proxying, or retries.
  const response = await fetchImpl(SOURCE_URL, {
    headers: { Accept: 'text/html', 'User-Agent': 'ScholarMetricsUpdater/1.0' },
    signal: AbortSignal.timeout(25000),
  });
  if (!response.ok) throw new Error(`Scholar returned HTTP ${response.status}; the existing JSON was kept.`);
  const responseUrl = new URL(response.url);
  if (responseUrl.hostname !== 'scholar.google.com' || responseUrl.pathname !== '/citations'
    || responseUrl.searchParams.get('user') !== SCHOLAR_ID) {
    throw new Error('Scholar redirected away from the expected public profile; the existing JSON was kept.');
  }
  const html = await response.text();
  const metrics = parseScholarMetrics(html);
  const document = {
    schema_version: 1,
    scholar_id: SCHOLAR_ID,
    ...metrics,
    updated_at: new Date().toISOString(),
    source_url: SOURCE_URL,
  };
  // Parse and validate first. Replace the old file only after a complete temporary write.
  await mkdir(dirname(outputPath), { recursive: true });
  const temporaryPath = `${outputPath}.${process.pid}.${Date.now()}.tmp`;
  try {
    await writeFile(temporaryPath, `${JSON.stringify(document, null, 2)}\n`, { encoding: 'utf8', flag: 'wx' });
    await rename(temporaryPath, outputPath);
  } catch (error) {
    await unlink(temporaryPath).catch(() => {});
    throw error;
  }
  return document;
}

async function main() {
  const args = process.argv.slice(2);
  if (args.length === 2 && args[0] === '--fixture') {
    const metrics = parseScholarMetrics(await readFile(resolve(args[1]), 'utf8'));
    console.log(JSON.stringify({ fixture_only: true, scholar_id: SCHOLAR_ID, ...metrics }, null, 2));
    return; // Fixture input never creates or replaces the published JSON.
  }
  if (args.length !== 0) throw new Error('Usage: node update-scholar.mjs [--fixture path/to/synthetic.html]');
  const metrics = await runUpdate();
  console.log(`Saved verified metrics to ${OUTPUT_PATH}; successful retrieval at ${metrics.updated_at}.`);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => {
    console.error(`Update failed: ${error.message}`);
    process.exitCode = 1;
  });
}
